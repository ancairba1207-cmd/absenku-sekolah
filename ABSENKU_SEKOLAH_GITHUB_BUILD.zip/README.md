# ABSENKU SEKOLAH

SD INPRES 3/77 PATTIMPA

Proyek sumber untuk membangun aplikasi Android ABSENKU SEKOLAH.
Jangan memasukkan `sekolah.db` ke repository jika berisi data nyata.

Fitur sumber mencakup absensi siswa, guru/tendik, QR, laporan, export Excel,
dan import Dapodik pada versi sumber yang dipakai.
